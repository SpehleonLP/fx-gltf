/* This file defines data structures so that accessors can
 * be interacted with as STL containers
 *
 * E.g:
 *
	std::vector<glm::vec3> position;

	for (auto const & attrib : primitive.attributes)
	{
		if(attrib.first == "POSITION")
		{
			stdAccessorVec3 position_array(document, attrib.second);
			position = std::vector<glm::vec3>(position_array.begin(), position_array.end());
		}
	}
 *
 * When given a fx::gltf::Document &, int accessor pair
 * it will throw an error if there is any risk of a buffer
 * overrun when the iterator class is used in a standard way.
 *
 * could stand to undergo more testing, but seems to work for my purposes.
 *
 */

#ifndef GLTF_STL_ACCESSOR_H
#define GLTF_STL_ACCESSOR_H
#include <limits>
#include <array>
#include <cstring> //memcpy

namespace fx
{

namespace gltf
{
class Document;
}

namespace Spehleon
{

template<int>
struct ComponentTypeInfo { enum { Columns = 1, ElementsPerColumn = 1, }; };

template<> struct ComponentTypeInfo<1> { enum { Columns = 1, ElementsPerColumn = 1, }; };
template<> struct ComponentTypeInfo<2> { enum { Columns = 1, ElementsPerColumn = 2, }; };
template<> struct ComponentTypeInfo<3> { enum { Columns = 1, ElementsPerColumn = 3, }; };
template<> struct ComponentTypeInfo<4> { enum { Columns = 1, ElementsPerColumn = 4, }; };
template<> struct ComponentTypeInfo<5> { enum { Columns = 2, ElementsPerColumn = 2, }; };
template<> struct ComponentTypeInfo<6> { enum { Columns = 3, ElementsPerColumn = 3, }; };
template<> struct ComponentTypeInfo<7> { enum { Columns = 4, ElementsPerColumn = 4, }; };


//this class copies bufferview stuffs from the fx::gltf::Document file
//this stuffs doesn't need templated, so we can avoid including the fx::gltf header
class gltfAccessorBase
{
public:
	gltfAccessorBase(const fx::gltf::Document & doc, size_t accessor);

	inline bool empty() const { return begin == nullptr; }
	inline int  size() const { return count; }

protected:
//copy values so we don't have too many header includes
//accessor stuff
	int type;
	int component_type;
	bool normalized;
	int count;

//buffer view
	int             stride;

//buffer stuff
	const uint8_t * begin;

//index buffer stuff
	const uint8_t * indices;
	int             index_stride;
	int             index_type;
	int             index_count;

// are indices garunteed to be sorted????
	int ReadIndex(int i) const;

//fundamentally it just isn't possible to deal with this stuff unless we get it from a runtime number to a compile time number.
//once that's done the compiler can hella optimize it for us, instead of us worrying about optimizing it.

	//the typeinfo switch goes first b/c we can get the typeinfo from the specilization of the stdaccessor template
	template<typename T>
	static void ReadAccessorValue(T * dst, int length, const uint8_t * src, int componentType, int typeInfo, bool normalize);

	//type goes second because it's impossible to know it at compile time
	template<typename T, int >
	static void ReadAccessorValue1(T * dst, const uint8_t * src, int componentType, bool normalize);

	template<typename T, typename input_type, int>
	static void ReadAccessorValue2(T * dst, const uint8_t * src, bool normalize);
};


template<typename ElementType, int typeID, typename AliasType = std::array<ElementType, ComponentTypeInfo<typeID>::Columns * ComponentTypeInfo<typeID>::ElementsPerColumn> >
class stdAccessor : public gltfAccessorBase
{
typedef gltfAccessorBase super;
public:
enum {
	TypeId  = typeID,
	Columns = ComponentTypeInfo<typeID>::Columns,
	ElementsPerColumn =  ComponentTypeInfo<typeID>::ElementsPerColumn,
};

typedef std::array<ElementType, Columns * ElementsPerColumn> array_type;
typedef AliasType                 value_type;

	stdAccessor(const fx::gltf::Document & doc, size_t accessor) : super(doc, accessor)
	{
		if(typeID != type)
			throw std::runtime_error("gltf accessor type does not match type of stdAccessor");
	}

	class Iterator : public std::iterator<std::random_access_iterator_tag, const value_type, ptrdiff_t, const value_type*, const value_type&>
	{
	public:

		Iterator() : parent(nullptr), index(0), evaluated(false) {}

		bool operator==(const Iterator & that) const { return parent == that.parent && index == that.index; }
		bool operator!=(const Iterator & that) const { return parent != that.parent || index != that.index; }
		bool operator< (const Iterator & that) const { return parent <  that.parent || index <  that.index; }
		bool operator<=(const Iterator & that) const { return parent <= that.parent || index <= that.index; }
		bool operator> (const Iterator & that) const { return parent >  that.parent || index >  that.index; }
		bool operator>=(const Iterator & that) const { return parent >= that.parent || index >= that.index; }

		const value_type & operator*()
		{
			if(evaluated == false)
			{
				//cache the result (this makes it possible for STL to recognize this as an input iterator)
				const_cast<Iterator*>(this)->evaluated = true;
				const_cast<Iterator*>(this)->result = parent->At(index);
			}

			return result;
		}

		const value_type * operator->() const
		{
			if(evaluated == false)
			{
				const_cast<Iterator*>(this)->evaluated = true;
				const_cast<Iterator*>(this)->result = parent->At(index);
			}

			return &result;
		}

		const value_type operator[](int i) const { return parent->At(index+i); }

		Iterator operator++(int)
		{
			Iterator itr(*this);
			index += 1;
			evaluated = false;
			return itr;
		}

		Iterator & operator--(int)
		{
			Iterator itr(*this);
			index -= 1;
			evaluated = false;
			return itr;
		}

		Iterator operator++()
		{
			index += 1;
			evaluated = false;
			return *this;
		}

		Iterator & operator--()
		{
			index -= 1;
			evaluated = false;
			return *this;
		}

		Iterator operator+(int n) { return Iterator(parent, index + n);	}
		Iterator operator-(int n) {	return Iterator(parent, index - n);	}

		Iterator & operator+=(int n)
		{
			index += n;
			evaluated = false;
			return *this;
		}

		Iterator & operator-=(int n)
		{
			index -= n;
			evaluated = false;
			return *this;
		}

		ptrdiff_t operator-(const Iterator & it) { return (index - it.index); }

	protected:
	friend class stdAccessor<ElementType, typeID, AliasType>;
		Iterator(const stdAccessor   * parent, int index) : parent(parent), index(index) {}

		const stdAccessor   * parent;
		int                   index;
		bool                  evaluated;
		value_type            result;
	};

//these iterators are always read only
	Iterator begin() const
	{
		return Iterator(this, 0);
	}

	Iterator end() const
	{
		return Iterator(this, count);
	}

	value_type operator[](int index) const { return At(index); }

	value_type At(int index) const
	{
		value_type ret;

		int read = ReadIndex(index);

		if(read == -1)
		{
			int i = 0;
			for(int x = 0; x < Columns; ++x)
			{
				for(int y = 0; y < ElementsPerColumn; ++y, ++i)
				{
					if(x == y && Columns != 1)
						((ElementType*) &ret)[i] = 1;
					else
						((ElementType*) &ret)[i] = 0;
				}
			}
		}
		else
			ReadAccessorValue1<ElementType, typeID>((ElementType*) &ret, super::begin + index * stride, component_type, super::normalized);

		return ret;
	}
};

//the typeinfo switch goes first b/c we can get the typeinfo from the specilization of the stdaccessor template
template<typename T>
inline void gltfAccessorBase::ReadAccessorValue(T * dst, int length, const uint8_t * src, int componentType, int typeInfo, bool normalize)
{
	switch(typeInfo)
	{
	case 1: ReadAccessorValue1<T, ComponentTypeInfo<1> >(dst, src, componentType, normalize); break;
	case 2: ReadAccessorValue1<T, ComponentTypeInfo<2> >(dst, src, componentType, normalize); break;
	case 3: ReadAccessorValue1<T, ComponentTypeInfo<3> >(dst, src, componentType, normalize); break;
	case 4: ReadAccessorValue1<T, ComponentTypeInfo<4> >(dst, src, componentType, normalize); break;
	case 5: ReadAccessorValue1<T, ComponentTypeInfo<5> >(dst, src, componentType, normalize); break;
	case 6: ReadAccessorValue1<T, ComponentTypeInfo<6> >(dst, src, componentType, normalize); break;
	case 7: ReadAccessorValue1<T, ComponentTypeInfo<7> >(dst, src, componentType, normalize); break;
	default:  throw std::runtime_error("unrecognized type id.");
	}
}

//type goes second because it's impossible to know it at compile time
template<typename T, int typeInfo>
inline void gltfAccessorBase::ReadAccessorValue1(T * dst, const uint8_t * src, int componentType, bool normalize)
{
	switch(componentType)
	{
	case 5120: ReadAccessorValue2<T,  int8_t , typeInfo>(dst, src, normalize); break;
	case 5121: ReadAccessorValue2<T, uint8_t , typeInfo>(dst, src, normalize); break;
	case 5122: ReadAccessorValue2<T,  int16_t, typeInfo>(dst, src, normalize); break;
	case 5123: ReadAccessorValue2<T, uint16_t, typeInfo>(dst, src, normalize); break;
	case 5124: ReadAccessorValue2<T,  int32_t, typeInfo>(dst, src, normalize); break;
	case 5125: ReadAccessorValue2<T, uint32_t, typeInfo>(dst, src, normalize); break;
	case 5126: ReadAccessorValue2<T, float   , typeInfo>(dst, src, normalize); break;
	default: throw std::runtime_error("unrecognized component type id.");
	}
}

template<typename T, typename input_type, int typeInfo>
inline void gltfAccessorBase::ReadAccessorValue2(T * dst, const uint8_t * src, bool normalize)
{
//the matrix is padded, so we need to copy to a buffer before dealing with it.
//compiler will remove this for us if it's not a matrix :)
	uint8_t buffer[ComponentTypeInfo<typeInfo>::Columns*ComponentTypeInfo<typeInfo>::ElementsPerColumn];

	if(ComponentTypeInfo<typeInfo>::Columns > 1 && ((ComponentTypeInfo<typeInfo>::ElementsPerColumn * sizeof(input_type)) % 4) != 0)
	{
		int stride = (ComponentTypeInfo<typeInfo>::ElementsPerColumn * sizeof(input_type));
		stride += 4 - (stride % 4);

//compiler can loop unroll b/c it's a compile time constant!!!!
		for(int i = 0; i < ComponentTypeInfo<typeInfo>::ElementsPerColumn; ++i)
		{
			memcpy(&buffer[i * ComponentTypeInfo<typeInfo>::ElementsPerColumn], &src[stride*i], ComponentTypeInfo<typeInfo>::ElementsPerColumn * sizeof(input_type));
		}

		src = buffer;
	}

//okay now we have a src jigger that we know doesn't have padding, so we can just copy it directly.

	if(normalize == false)
	{
		for(size_t i = 0; i < ComponentTypeInfo<typeInfo>::Columns*ComponentTypeInfo<typeInfo>::ElementsPerColumn; ++i)
		{
			dst[i] = ((const input_type*)src)[i];
		}
	}
	else
	{
		if(std::numeric_limits<input_type>::is_signed)
		{
			for(size_t i = 0; i < ComponentTypeInfo<typeInfo>::Columns*ComponentTypeInfo<typeInfo>::ElementsPerColumn; ++i)
			{
				dst[i] = std::max<T>(-1, ((const input_type*)src)[i] / (float) std::numeric_limits<const input_type>::max());
			}
		}
		else
		{
			for(size_t i = 0; i < ComponentTypeInfo<typeInfo>::Columns*ComponentTypeInfo<typeInfo>::ElementsPerColumn; ++i)
			{
				dst[i] = ((input_type*)src)[i] / (float) std::numeric_limits<input_type>::max();
			}
		}
	}
}

}

}

#include <glm/glm.hpp>
#include <glm/vec2.hpp>
#include <glm/vec3.hpp>
#include <glm/vec4.hpp>
#include <glm/mat2x2.hpp>
#include <glm/mat3x3.hpp>
#include <glm/mat4x4.hpp>
#include <glm/gtc/quaternion.hpp>

namespace fx
{

namespace gltf
{

typedef fx::Spehleon::stdAccessor<  int, 1, int> stdAccessorIVec1;
typedef fx::Spehleon::stdAccessor<  int, 2, ::glm::ivec2> stdAccessorIVec2;
typedef fx::Spehleon::stdAccessor<  int, 3, ::glm::ivec3> stdAccessorIVec3;
typedef fx::Spehleon::stdAccessor<  int, 4, ::glm::ivec4> stdAccessorIVec4;

typedef fx::Spehleon::stdAccessor<float, 1, float> stdAccessorVec1;
typedef fx::Spehleon::stdAccessor<float, 2, ::glm::vec2> stdAccessorVec2;
typedef fx::Spehleon::stdAccessor<float, 3, ::glm::vec3> stdAccessorVec3;
typedef fx::Spehleon::stdAccessor<float, 4, ::glm::vec4> stdAccessorVec4;

typedef fx::Spehleon::stdAccessor<float, 4, ::glm::quat> stdAccessorQuat;
typedef fx::Spehleon::stdAccessor<float, 5, ::glm::mat2> stdAccessorMat2;
typedef fx::Spehleon::stdAccessor<float, 6, ::glm::mat3> stdAccessorMat3;
typedef fx::Spehleon::stdAccessor<float, 7, ::glm::mat4> stdAccessorMat4;

}


}

#endif // GLTFACCESSORRANGE_H

#include "gltfaccessorrange.h"
#include "../fx-gltf/include/fx/gltf.h"
#include <algorithm>

namespace fx
{

namespace Spehleon
{

static int GetStride(::fx::gltf::Accessor::ComponentType component_type, fx::gltf::Accessor::Type type);
static int GetBytesInType(::fx::gltf::Accessor::ComponentType component_type);

gltfAccessorBase::gltfAccessorBase(const ::fx::gltf::Document & doc, size_t i)
{
	if(!(i < doc.accessors.size()))
		throw std::runtime_error("requested an accessor which doesn't exist.");

	const fx::gltf::Accessor & accessor = doc.accessors[i];

	if(accessor.componentType == fx::gltf::Accessor::ComponentType::None)
		throw std::runtime_error("gltf accessor array is invalid, (component type null)");

	type           = (int) accessor.type;
	component_type = (int) accessor.componentType;
	normalized     = accessor.normalized;
	count          = accessor.count;


//set up index buffer if we're sparse...
	indices        = nullptr;
	index_type     = (int) accessor.sparse.indices.componentType;
	index_stride   = 0;
	index_count    = (int) accessor.sparse.count;

	begin = nullptr;

	int b_view = accessor.bufferView;

//set up buffer view if we're sparse
	if(b_view == -1)
	{
		b_view  = accessor.bufferView;

		const fx::gltf::BufferView & view = doc.bufferViews[accessor.sparse.indices.bufferView];

		if(!((size_t)view.buffer < doc.buffers.size()))
			throw std::runtime_error("gltf buffer view has invalid buffer address");

		if(view.byteLength < accessor.byteOffset + (accessor.count-1) * view.byteStride)
			throw std::runtime_error("gltf buffer view is too short for accessor");


		const fx::gltf::Buffer     & buffer = doc.buffers[view.buffer];

		if(buffer.data.empty())
			throw std::runtime_error("gltf buffer was not loaded");

		if(buffer.data.size() < view.byteOffset + view.byteLength)
			throw std::runtime_error("gltfAccessorRange: buffer overrun");

		indices       = &buffer.data[view.byteOffset];
		index_stride = std::max<int>(view.byteStride, GetBytesInType(accessor.sparse.indices.componentType));
	}

	const fx::gltf::BufferView & view = doc.bufferViews[b_view];

	if(!((size_t)view.buffer < doc.buffers.size()))
		throw std::runtime_error("gltf buffer view has invalid buffer address");

	if(view.byteLength < accessor.byteOffset + (accessor.count-1) * view.byteStride)
		throw std::runtime_error("gltf buffer view is too short for accessor");

	const fx::gltf::Buffer     & buffer = doc.buffers[view.buffer];

	if(buffer.data.empty())
		throw std::runtime_error("gltf buffer was not loaded");

	if(buffer.data.size() < view.byteOffset + view.byteLength)
		throw std::runtime_error("gltfAccessorRange: buffer overrun");

	stride = std::max<int>(view.byteStride, GetStride(accessor.componentType, accessor.type));
	begin  = &buffer.data[view.byteOffset + accessor.byteOffset];
}

static int GetStride(::fx::gltf::Accessor::ComponentType component_type, ::fx::gltf::Accessor::Type type)
{
	int bytes = GetBytesInType(component_type);

	switch(type)
	{
	case fx::gltf::Accessor::Type::Scalar:
		return bytes;
	case fx::gltf::Accessor::Type::Vec2:
		return bytes * 2;
	case fx::gltf::Accessor::Type::Vec3:
		return bytes * 3;
	case fx::gltf::Accessor::Type::Vec4:
		return bytes * 4;
	case fx::gltf::Accessor::Type::Mat2:
		bytes *= 2;
		bytes += 3 - (bytes % 4);
		return bytes * 2;
	case fx::gltf::Accessor::Type::Mat3:
		bytes *= 3;
		bytes += 3 - (bytes % 4);
		return bytes * 3;
	case fx::gltf::Accessor::Type::Mat4:
		bytes *= 4;
		bytes += 3 - (bytes % 4);
		return bytes * 4;
	default:
		return bytes;
	}

	return bytes;
}

static int GetBytesInType(::fx::gltf::Accessor::ComponentType component_type)
{
	switch(component_type)
	{
	case fx::gltf::Accessor::ComponentType::Byte:
		return 1;
	case fx::gltf::Accessor::ComponentType::UnsignedByte:
		return 1;
	case fx::gltf::Accessor::ComponentType::Short:
		return 2;
	case fx::gltf::Accessor::ComponentType::UnsignedShort:
		return 2;
	case fx::gltf::Accessor::ComponentType::UnsignedInt:
		return 4;
	case fx::gltf::Accessor::ComponentType::Float:
		return 4;
	default:
		return 1;
	}

	return 1;
}

template<typename T>
static int ReadIndex2(const uint8_t * src, int stride, int length, int index)
{
	for(int i = 0; i < length; ++i)
	{
		if(index == (int)  ((T*) (src+stride*i))[0])
			return i;
	}

	return -1;
}

int gltfAccessorBase::ReadIndex(int i) const
{
	if(indices == nullptr)
		return i;

	switch(index_type)
	{
	case 5120: return ReadIndex2<int8_t>(indices, index_stride, index_count, i);
	case 5121: return ReadIndex2<uint8_t>(indices, index_stride, index_count, i);
	case 5122: return ReadIndex2<int16_t>(indices, index_stride, index_count, i);
	case 5123: return ReadIndex2<uint16_t>(indices, index_stride, index_count, i);
	case 5124: return ReadIndex2<int32_t>(indices, index_stride, index_count, i);
	case 5125: return ReadIndex2<uint32_t>(indices, index_stride, index_count, i);
	case 5126: return ReadIndex2<float>(indices, index_stride, index_count, i);
	default: throw std::runtime_error("unrecognized component type id.");
	}

	return -1;
}



}

}
